#ID:22241108
import socket

def client_working_hours():
    host = socket.gethostname()
    port = 5050
    client_socket = socket.socket()
    client_socket.connect((host, port))
    message = input("Enter amount of working hours: ")

    while message.lower().strip() != 'Bye Bye!':
        client_socket.send(message.encode())
        data = client_socket.recv(1024).decode()
        print('Payable amount: ' + data)
        message = input("Enter amount of working hours: ")
    client_socket.close()

#Function call
if __name__ == '__main__':
   client_working_hours()